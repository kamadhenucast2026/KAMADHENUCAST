const menuBtn = document.querySelector('.menu-btn');
const nav = document.querySelector('.nav');

menuBtn?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded', String(open));
});

document.querySelectorAll('.nav a').forEach(link => {
  link.addEventListener('click', () => nav.classList.remove('open'));
});

document.getElementById('year').textContent = new Date().getFullYear();

document.getElementById('quoteForm').addEventListener('submit', function (e) {
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const company = document.getElementById('company').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const product = document.getElementById('product').value;
  const message = document.getElementById('message').value.trim();

  const text = [
    'Hello KAMADHENU CAST, I need a quotation.',
    '',
    `Name: ${name}`,
    `Company: ${company || '-'}`,
    `Phone: ${phone}`,
    `Product: ${product}`,
    `Requirement: ${message || '-'}`
  ].join('\n');

  window.open(`https://wa.me/919994108939?text=${encodeURIComponent(text)}`, '_blank');
});
