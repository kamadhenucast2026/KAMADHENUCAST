# KAMADHENU CAST Website

Updated using the supplied company catalog.

Files:
- index.html
- styles.css
- script.js
- logo.png
- catalog.pdf
- README.txt

Contact:
Phone / WhatsApp: +91 99941 08939
Email: kamadhenucast@gmail.com
Address: D.No-1/439, Shop No.G22, Siva Complex, Bodipalayam Road, Malumichampatty, Coimbatore

Catalog-backed areas included:
- Forklifts
- Hand / Electric / Powered Pallet Trucks
- Walkie / Electric / Counterbalance Stackers
- Reach Trucks and Dock Levelers
- Plastic Pallets
- Wooden Boxes & Wooden Pallets
- Heavy Duty Industrial Racks
- Boom Lifts, Scissor Lifts and TeleHandlers
- HVLS Fans, Grid Ceiling Fans and Industrial Mobile Fans
- 3D Scanning, Point Cloud, 3D Modelling and Engineering Output
- Composites, Metal Fabrication and 3D Printing
- Forklift Spare Parts

Open index.html in a browser to preview the website.
The company catalog is included as catalog.pdf and linked from the site.
